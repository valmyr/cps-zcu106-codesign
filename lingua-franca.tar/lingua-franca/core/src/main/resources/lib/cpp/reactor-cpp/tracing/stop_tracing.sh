#!/bin/bash

lttng destroy
